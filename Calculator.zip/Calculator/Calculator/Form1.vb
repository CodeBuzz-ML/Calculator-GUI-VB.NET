﻿Public Class Form1
    Dim mainStrBeforeEq As String
    Dim mainStrAfterEq As String
    Dim activeEq As Integer = 0
    Dim activeOperator As String
    Dim intMain1 As Integer
    Dim intMain2 As Integer
    Dim Result As Integer

    'Form Load Events
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblResult.Text = ""
        lblEqTillNow.Text = ""
    End Sub


    'Number Button Clicks configured
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn1.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn1.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If

    End Sub
    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn2.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn2.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn3.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn3.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn4.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn4.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn5.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn5.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn5.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn5.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn7.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn7.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn8.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn8.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn9.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn9.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub
    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        If activeEq = 0 Then
            mainStrBeforeEq = mainStrBeforeEq + btn0.Text
            lblEqTillNow.Text = mainStrBeforeEq
        ElseIf activeEq = 1 Then
            mainStrAfterEq = mainStrAfterEq + btn0.Text
            If activeOperator = "+" Then
                lblEqTillNow.Text = mainStrBeforeEq + " + " + mainStrAfterEq
            ElseIf activeOperator = "-" Then
                lblEqTillNow.Text = mainStrBeforeEq + " - " + mainStrAfterEq
            ElseIf activeOperator = "*" Then
                lblEqTillNow.Text = mainStrBeforeEq + " * " + mainStrAfterEq
            ElseIf activeOperator = "/" Then
                lblEqTillNow.Text = mainStrBeforeEq + " / " + mainStrAfterEq
            End If

        End If
    End Sub

    'Building the logic to get the operator
    Private Sub btnPlus_Click(sender As Object, e As EventArgs) Handles btnPlus.Click
        activeEq = 1
        lblEqTillNow.Text = lblEqTillNow.Text + " + "
        activeOperator = "+"
    End Sub
    Private Sub btnMult_Click(sender As Object, e As EventArgs) Handles btnMult.Click
        activeEq = 1
        lblEqTillNow.Text = lblEqTillNow.Text + " * "
        activeOperator = "*"
    End Sub
    Private Sub btnMinus_Click(sender As Object, e As EventArgs) Handles btnMinus.Click
        activeEq = 1
        lblEqTillNow.Text = lblEqTillNow.Text + " - "
        activeOperator = "*"
    End Sub
    Private Sub btnDiv_Click(sender As Object, e As EventArgs) Handles btnDiv.Click
        activeEq = 1
        lblEqTillNow.Text = lblEqTillNow.Text + " / "
        activeOperator = "/"
    End Sub

    Private Sub btnGetResult_Click(sender As Object, e As EventArgs) Handles btnGetResult.Click
        intMain1 = CInt(mainStrBeforeEq)
        intMain2 = CInt(mainStrAfterEq)
        If activeOperator = "+" Then
            Result = intMain1 + intMain2
            lblResult.Text = Result

        ElseIf activeOperator = "-" Then
            Result = intMain1 - intMain2
            lblResult.Text = Result

        ElseIf activeOperator = "*" Then
            Result = intMain1 * intMain2
            lblResult.Text = Result

        ElseIf activeOperator = "/" Then
            Result = intMain1 / intMain2
            lblResult.Text = Result
        End If
    End Sub

    Private Sub btnClr_Click(sender As Object, e As EventArgs) Handles btnClr.Click
        mainStrAfterEq = ""
        mainStrBeforeEq = ""
        activeOperator = ""
        activeEq = 0
        Result = 0
        intMain1 = 0
        intMain2 = 0
        lblEqTillNow.Text = ""
        lblResult.Text = ""
    End Sub
End Class
